/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package crip;

/**
 *
 * @author Alex
 */
public enum Operaciones {
    SUMA, MULTIPLICACION
}
